import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const HomeKurir = () => {
  return (
    <View>
      <Text>HomeKurir</Text>
    </View>
  )
}

export default HomeKurir

const styles = StyleSheet.create({})