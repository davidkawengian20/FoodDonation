import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const HomeDonatur = () => {
  return (
    <View>
      <Text>HomeDonatur</Text>
    </View>
  )
}

export default HomeDonatur

const styles = StyleSheet.create({})