import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const HomeAdmin = () => {
  return (
    <View>
      <Text>HomeAdmin</Text>
    </View>
  )
}

export default HomeAdmin

const styles = StyleSheet.create({})