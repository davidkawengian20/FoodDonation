import Background from './background.png'
import Logo from './logo.png'
import BackgroundSignIn from './backgroundSignIn.png'
import Backgrounds from './backgrounds.png'
import Close from './close.png'
import ProfilePic from './profilePic.png'
import UploadRegis from './uploadRegis.png'

export {Background, Backgrounds, Logo, BackgroundSignIn, Close, ProfilePic, UploadRegis}